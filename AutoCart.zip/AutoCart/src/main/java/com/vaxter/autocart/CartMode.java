package com.vaxter.autocart;

public enum CartMode {
    SINGLE,
    SPAM
}