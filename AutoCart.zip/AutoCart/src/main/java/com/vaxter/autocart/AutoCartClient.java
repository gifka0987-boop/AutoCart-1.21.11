package com.vaxter.autocart;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import org.lwjgl.glfw.GLFW;

public class AutoCartClient implements ClientModInitializer {

    private static KeyBinding cartKey;
    private static KeyBinding modeKey;

    private static CartMode mode = CartMode.SINGLE;

    @Override
    public void onInitializeClient() {

        cartKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding(
                        "key.autocart.use",
                        InputUtil.Type.KEYSYM,
                        GLFW.GLFW_KEY_R,
                        "category.autocart"
                )
        );

        modeKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding(
                        "key.autocart.mode",
                        InputUtil.Type.KEYSYM,
                        GLFW.GLFW_KEY_V,
                        "category.autocart"
                )
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {

            while (modeKey.wasPressed()) {
                mode = mode == CartMode.SINGLE ? CartMode.SPAM : CartMode.SINGLE;
            }

            while (cartKey.wasPressed()) {
                placeCart(client);
            }

        });
    }

    private void placeCart(MinecraftClient client) {

        if (client.player == null) return;

        BlockPos pos = client.player.getBlockPos()
                .offset(client.player.getHorizontalFacing());

        BlockHitResult hit = new BlockHitResult(
                Vec3d.ofCenter(pos),
                Direction.UP,
                pos,
                false
        );

        client.interactionManager.interactBlock(
                client.player,
                Hand.MAIN_HAND,
                hit
        );

        client.interactionManager.interactItem(client.player, Hand.MAIN_HAND);
    }
}