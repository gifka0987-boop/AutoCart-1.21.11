package com.vaxter.autocart;

import net.fabricmc.api.ModInitializer;

public class AutoCartMod implements ModInitializer {

    @Override
    public void onInitialize() {
        System.out.println("AutoCart loaded");
    }
}